<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="../lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="../lib/animate-css/animate.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="../css/style.css" rel="stylesheet">

    <!-- =======================================================
        Theme Name: Imperial
        Theme URL: https://bootstrapmade.com/imperial-free-onepage-bootstrap-theme/
        Author: BootstrapMade.com
        Author URL: https://bootstrapmade.com
    ======================================================= -->

    <!-- Script necessário para leitura de Estado e Cidade-->
    <script type="text/javascript" src="http://cidades-estados-js.googlecode.com/files/cidades-estados-v0.2.js"></script> 
    <script type="text/javascript">
        window.onload = function() {
            new dgCidadesEstados( 
                document.getElementById('estado'), 
                document.getElementById('cidade'), 
                true
            );
        }
    </script>

</head>

<body>
    <!--==========================
    Header Section
    ============================-->
    <header id="header">
        <div class="container">

            <div id="logo" class="pull-left">
            <!--Trocar ou apagar - Caso haja um logo-->
            <!-- <a href="#hero"><img src="img/logo.png" alt="" title="" /></img></a> -->
            <!-- Uncomment below if you prefer to use a text image -->
            <h1><a href="#hero">JTI</a></h1>
            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu">
                <li class="menu-active"><li><a href="../view/perfilAcademico.php">Meu Perfil</a></li>
                <li><a href="../view/palestrasAcademico.php">Palestras</a></li>
                <li><a href="../view/minicursosAcademico.php">Minicursos</a></li>
                <li><a href="../view/horariosAcademico.php">Meus horários</a></li>
                </ul>
            </nav>
            <!-- #nav-menu-container -->
        </div>
        
    </header>
    <!-- #header -->

    <div class="container cont">
        <!-- Imagem do perfil -->
        <div>
        <section id="portfolio" class="col-md-3">
            <div>
                <a class="portfolio-item" style="background-image: url(../img/pordosol.png);"  href="">
                <div class="details">
                    <h4>Acadêmico</h4>
                    <span>Hello Jhow</span>
                </div>
                </a>
            </div>
        </section>
            
        <div class="col-md-5 col-sm-8 col-xs-12 col-md-offset-1" align="left">
            <form action="#cadastroUsuarioController.php" method="POST" class="form-horizontal" align="left">
                </br></br></br>
                <div align="center" >
                  <legend><b style="color:#000000">Dados do Usuário</b></legend>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label" for="email">E-mail:</label>
                  <div class="col-md-9">
                    <input type="email" class="form-control" name="email" id="email">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label" for="senha">Senha:</label>
                  <div class="col-md-9">
                    <input type="text" class="form-control" name="senha" id="senha">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label" for="confirmacao_senha">Confirmação de senha:</label>
                  <div class="col-md-9">
                    <input type="text" class="form-control" name="confirmacao_senha" id="confirmacao_senha">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label" for="cpf">CPF:</label>
                  <div class="col-md-9">
                    <input type="text" class="form-control" name="cpf" id="cpf"> 
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label" for="nome">Nome:</label>
                  <div class="col-md-9">
                    <input type="text" class="form-control" name="nome" id="nome"> 
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label">Sexo:</label>
                  <div class="col-md-9">
                    <select class="form-control">
                        <option></option>
                        <option name="sexo" value="masculino">Masculino</option>
                        <option name="sexo" value="feminino">Feminino</option>
                        <option name="sexo" value="outro">Outro</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label" for="curso">Curso:</label>
                  <div class="col-md-9">
                    <input type="text" class="form-control" name="curso" id="curso">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label" for="universidade">Universidade:</label>
                  <div class="col-md-9">
                    <input type="text" class="form-control" name="universidade" id="universidade">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label" for="ano_entrada">Ano de ingresso:</label>
                  <div class="col-md-9">
                    <input type="text" class="form-control" name="ano_entrada" id="ano_entrada">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label" for="data_nascimento">Data de nascimento*:</label>
                  <div class="col-md-9">
                  <input type="date" class="form-control" name="data_nascimento" id="data_nascimento">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label" for="rua">Rua:</label>
                  <div class="col-md-9">
                    <input type="text" class="form-control" name="rua" id="rua">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label" for="numero">Número:</label>
                  <div class="col-md-9">
                    <input type="text" class="form-control" name="numero" id="numero">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label" for="cep">CEP:</label>
                  <div class="col-md-9">
                    <input type="text" class="form-control" name="cep" id="cep">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label" for="complemento">Complemento:</label>
                  <div class="col-md-9">
                    <input type="text" class="form-control" name="complemento" id="complemento">
                  </div>
                </div>
                
                <div class="form-group">
                    <label for="estado" class="col-md-3 control-label">Estado:</label>
                    <div class="col-md-9">
                    <select class="form-control" name="estado" id="estado" disabled data-target="#cidade">
                        <option value="">Estado</option>
                    </select>
                    </div>
                </div>
                      
                <div class="form-group">
                    <label for="cidade" class="col-md-3 control-label">Cidade:</label>
                    <div class="col-md-9">
                    <select class="form-control" name="cidade" id="cidade" disabled>
                        <option value="">Cidade</option>
                    </select>
                    </div>
                </div>
                
                <div class="form-group">
                  <label class="col-md-3 control-label" for="">Contato fixo:</label>
                  <div class="col-md-9">
                    <input type="text" class="form-control" name="fixo" id="fixo">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label" for="">Contato celular:</label>
                  <div class="col-md-9">
                    <input type="text" class="form-control" name="celular" id="celular">
                  </div>
                </div>
                <div class="form-group">
                  <div class="col-md-5 col-md-offset-7"> 
                    <button class="btn btn-primary pull-right save" type="submit">
                      <span> Alterar</span>
                    </button>
                  </div>  
                </div>
              </form>
            </div>
</div>
    </div>


    <!-- #footer -->
    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

    <!-- Required JavaScript Libraries -->
    <script src="../lib/jquery/jquery.min.js"></script>
    <script src="../lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="../lib/superfish/hoverIntent.js"></script>
    <script src="../lib/superfish/superfish.min.js"></script>
    <script src="../lib/morphext/morphext.min.js"></script>
    <script src="../lib/wow/wow.min.js"></script>
    <script src="../lib/stickyjs/sticky.js"></script>
    <script src="../lib/easing/easing.js"></script>

    <!-- Template Specisifc Custom Javascript File -->
    <script src="../js/custom.js"></script>

    <script src="../contactform/contactform.js"></script>

    <!-- Estado e Cidade JS -->
    <script>
            var estados = [];
            
            function loadEstados(element) {
              if (estados.length > 0) {
                putEstados(element);
                $(element).removeAttr('disabled');
              } else {
                $.ajax({
                  url: 'https://api.myjson.com/bins/enzld',
                  method: 'get',
                  dataType: 'json',
                  beforeSend: function() {
                    $(element).html('<option>Carregando...</option>');
                  }
                }).done(function(response) {
                  estados = response.estados;
                  putEstados(element);
                  $(element).removeAttr('disabled');
                });
              }
            }
            
            function putEstados(element) {
            
              var label = $(element).data('label');
              label = label ? label : 'Estado';
            
              var options = '<option value="">' + label + '</option>';
              for (var i in estados) {
                var estado = estados[i];
                options += '<option value="' + estado.sigla + '">' + estado.nome + '</option>';
              }
            
              $(element).html(options);
            }
            
            function loadCidades(element, estado_sigla) {
              if (estados.length > 0) {
                putCidades(element, estado_sigla);
                $(element).removeAttr('disabled');
              } else {
                $.ajax({
                  url: theme_url + '/assets/json/estados.json',
                  method: 'get',
                  dataType: 'json',
                  beforeSend: function() {
                    $(element).html('<option>Carregando...</option>');
                  }
                }).done(function(response) {
                  estados = response.estados;
                  putCidades(element, estado_sigla);
                  $(element).removeAttr('disabled');
                });
              }
            }
            
            function putCidades(element, estado_sigla) {
              var label = $(element).data('label');
              label = label ? label : 'Cidade';
            
              var options = '<option value="">' + label + '</option>';
              for (var i in estados) {
                var estado = estados[i];
                if (estado.sigla != estado_sigla)
                  continue;
                for (var j in estado.cidades) {
                  var cidade = estado.cidades[j];
                  options += '<option value="' + cidade + '">' + cidade + '</option>';
                }
              }
              $(element).html(options);
            }
            
            document.addEventListener('DOMContentLoaded', function() {
              loadEstados('#estado');
              $(document).on('change', '#estado', function(e) {
                var target = $(this).data('target');
                if (target) {
                  loadCidades(target, $(this).val());
                }
              });
            }, false);
            
            
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</body>