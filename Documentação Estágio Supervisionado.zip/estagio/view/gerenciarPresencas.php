<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="../lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="../lib/animate-css/animate.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="../css/style.css" rel="stylesheet">

    <!-- =======================================================
        Theme Name: Imperial
        Theme URL: https://bootstrapmade.com/imperial-free-onepage-bootstrap-theme/
        Author: BootstrapMade.com
        Author URL: https://bootstrapmade.com
    ======================================================= -->

    <script type="text/javascript">
        //Rodar script assim que abrir a página
        window.onload = initPage;
        function initPage(){
            var div_tabela = document.getElementById('atividades');

            //Array de Objetos temporário. Futuramente deverá ser pego do BD
            var atividades = [
                {
                    nome : "Atividade Um", 
					tipo : "palestra",
                    aprovacao : true,
                    nome_ministrante : "Ministrante Três"
				},
                {
                    nome : "Atividade Dois", 
					tipo : "minicurso",
                    aprovacao : false,
                    nome_ministrante : "Ministrante Um"
                },
                {
                    nome : "Atividade Três", 
					tipo : "minicurso",
                    aprovacao : true,
                    nome_ministrante : "Ministrante Dois"
                }
            ]
            
            var preencherTabela = function(atividade){
                var el = document.createElement('tr'); //Cria uma <tr>
                //Insere o HTML restante dentro da div criada
                el.insertAdjacentHTML("beforeend", '<td>'+atividade.nome+'</td><td>'+atividade.tipo+'</td><td>'+atividade.aprovacao+'</td><td>'+atividade.nome_ministrante+'<td><input type="submit" value="Consultar"></td>')
                div_tabela.insertAdjacentElement("beforeend", el);      //Atribui a div criada a tabela 
            }
            
            atividades.forEach(preencherTabela);
        }       
    </script>

</head>

<body>
    <!--==========================
    Header Section
    ============================-->
    <header id="header">
        <div class="container">

            <div id="logo" class="pull-left">
            <!--Trocar ou apagar - Caso haja um logo-->
            <!-- <a href="#hero"><img src="img/logo.png" alt="" title="" /></img></a> -->
            <!-- Uncomment below if you prefer to use a text image -->
            <h1><a href="#hero">JTI</a></h1>
            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu">
                <li class="menu-active"><li><a href="../view/perfilMinistrante.php">Meu Perfil</a></li>
                <li><a href="../view/atividadesMinistrante.php">Atividades</a></li>
                <li><a href="../view/gerenciarPresencas.php">Lista de presença</a></li>
                </ul>
            </nav>
            <!-- #nav-menu-container -->
        </div>
        
    </header>
    <!-- #header -->

    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th scope="col" class="cabecalho">Nome</th>
                <th scope="col" class="cabecalho">Tipo</th>
                <th scope="col" class="cabecalho">Aprovação</th>
                <th scope="col" class="cabecalho">Ministrante</th>
                <th scope="col" class="cabecalho">Ação (Only his/her)</th>
            </tr>
        </thead>
        <tbody class="cabecalho" id="atividades">


            
        </tbody>
        
    </table>

    <!-- #footer -->
    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

    <!-- Required JavaScript Libraries -->
    <script src="../lib/jquery/jquery.min.js"></script>
    <script src="../lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="../lib/superfish/hoverIntent.js"></script>
    <script src="../lib/superfish/superfish.min.js"></script>
    <script src="../lib/morphext/morphext.min.js"></script>
    <script src="../lib/wow/wow.min.js"></script>
    <script src="../lib/stickyjs/sticky.js"></script>
    <script src="../lib/easing/easing.js"></script>

    <!-- Template Specisifc Custom Javascript File -->
    <script src="../js/custom.js"></script>

    <script src="../contactform/contactform.js"></script>

</body>