<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="../lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="../lib/animate-css/animate.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="../css/style.css" rel="stylesheet">

    <!-- =======================================================
        Theme Name: Imperial
        Theme URL: https://bootstrapmade.com/imperial-free-onepage-bootstrap-theme/
        Author: BootstrapMade.com
        Author URL: https://bootstrapmade.com
    ======================================================= -->

    <!-- JS para criação das cards dinâmicas -->
    <script type="text/javascript">
        //Rodar script assim que abrir a página
        window.onload = initPage;
        function initPage(){
            var div_portfolio = document.getElementById('portfolio');

            div_portfolio.appendChild(document.createElement('div'));
            debugger;
            div_portfolio.lastElementChild.classList.add("container", "wow", "fadeInUp");
            div_portfolio.lastElementChild.style.visibility = "visible";
            div_portfolio.lastElementChild.style.animationName = "fadeInUp";
            div_portfolio = div_portfolio.lastElementChild; 
            
            //Array de Objetos temporário. Futuramente deverá ser pego do BD
            var cards = [
                {
                    imagem : "url(../img/portfolio-3.jpg);", 
					descricao : "Descrição I",
                    titulo : "Palestra I"
				},
                {
                    imagem : "url(../img/portfolio-6.jpg);", 
					descricao : "Descrição II", 
					titulo : "Portfolio 2"
                }
            ]
        
            var criarCard = function(card){
                var el = document.createElement('div'); //Cria uma <div>
                el.classList.add('col-md-3',  'col-12', 'col-xl-2');   //Atribui classes à div criada
                el.insertAdjacentHTML("beforeend", '<a class=\"portfolio-item\" style=\"background-image:'+card.imagem+'\"><div class=\"details\"><h4>'+card.titulo+'</h4><span>'+card.descricao+'</span></div></a>')  //Insere o HTML restante dentro da div criada

                div_portfolio.insertAdjacentElement("beforeend", el);      //Atribui a div criada ao portfolio
            }
            
            cards.forEach(criarCard);
        }
            
    </script>

</head>

<body>
    <!--==========================
    Header Section
    ============================-->
    <header id="header">
        <div class="container">

            <div id="logo" class="pull-left">
            <!--Trocar ou apagar - Caso haja um logo-->
            <!-- <a href="#hero"><img src="img/logo.png" alt="" title="" /></img></a> -->
            <!-- Uncomment below if you prefer to use a text image -->
            <h1><a href="#hero">JTI</a></h1>
            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu">
                <li class="menu-active"><li><a href="../view/perfilAcademico.php">Meu Perfil</a></li>
                <li><a href="../view/palestrasAcademico.php">Palestras</a></li>
                <li><a href="../view/minicursosAcademico.php">Minicursos</a></li>
                <li><a href="../view/horariosAcademico.php">Meus horários</a></li>
                </ul>
            </nav>
            <!-- #nav-menu-container -->
        </div>
        
    </header>
    <!-- #header -->

    <!--==========================
    Porfolio Section
    ============================-->

    <!--
        Necessário exibir:
            1. Nome da palestra
            2. Imagem do palestrante
            3. Descrição da palestra
    -->
    <?php
    $nome_palestra = "Palestra I";
    $descricao_palestra = "Essa é a Palestra I ela fala sobre a história da Tecnologia de Informação (TI) que atualmente recebe o nome de Tecnologia de Informação e Comunicação (TIC), pois percebeu-se que a TIC está relacionada com o fluxo de informações de um negócio...etc...";
    $imagem_palestrante = "url(../img/portfolio-1.jpg);";
    ?>
    
    <section id="portfolio">
        <div class="row">

            <!-- div onde será inserido o JS -->            
            <!-- <p id="card"></p> -->
            <div id="card"></div>

            
        </div>
    </section>



    <!-- #footer -->
    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

    <!-- Required JavaScript Libraries -->
    <script src="../lib/jquery/jquery.min.js"></script>
    <script src="../lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="../lib/superfish/hoverIntent.js"></script>
    <script src="../lib/superfish/superfish.min.js"></script>
    <script src="../lib/morphext/morphext.min.js"></script>
    <script src="../lib/wow/wow.min.js"></script>
    <script src="../lib/stickyjs/sticky.js"></script>
    <script src="../lib/easing/easing.js"></script>

    <!-- Template Specisifc Custom Javascript File -->
    <script src="../js/custom.js"></script>

    <script src="../contactform/contactform.js"></script>

</body>