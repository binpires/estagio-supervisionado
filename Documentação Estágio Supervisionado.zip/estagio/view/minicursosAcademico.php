<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="../lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="../lib/animate-css/animate.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="../css/style.css" rel="stylesheet">

    <!-- =======================================================
        Theme Name: Imperial
        Theme URL: https://bootstrapmade.com/imperial-free-onepage-bootstrap-theme/
        Author: BootstrapMade.com
        Author URL: https://bootstrapmade.com
    ======================================================= -->

    <script type="text/javascript">
        //Rodar script assim que abrir a página
        window.onload = initPage;
        function initPage(){
            var div_portfolio = document.getElementById('minicursos');

            //Array de Objetos temporário. Futuramente deverá ser pego do BD
            var minicursos = [
                {
                    nome : "Minicurso I", 
					vagas : "15",
                    periodo : "matutino",
                    dias : "21-08; 22-08",
                    status_pagamento : "Pago"
				},
                {
                    nome : "Minicurso II", 
					vagas : "20",
                    periodo : "vespertino",
                    dias : "22-08; 24-08",
                    status_pagamento : "Não Pago"
                },
                {
                    nome : "Minicurso III", 
					vagas : "17",
                    periodo : "noturno",
                    dias : "23-08;25-08",
                    status_pagamento : "Não Pago"
                }
            ]
            
            var preencherTabela = function(minicurso){
                var el = document.createElement('tr'); //Cria uma <tr>
                //Insere o HTML restante dentro da div criada
                el.insertAdjacentHTML("beforeend", '<td>'+minicurso.nome+'</td><td>'+minicurso.vagas+'</td><td>'+minicurso.periodo+'</td><td>'+minicurso.dias+'</td><td>'+minicurso.status_pagamento+'</td><td><input type="submit" value="Consultar"></td>')
                div_portfolio.insertAdjacentElement("beforeend", el);      //Atribui a div criada ao portfolio
            }
            
            minicursos.forEach(preencherTabela);

            //ORDENAR RESULTADOS TRAZIDOS DO BD TAMBÉM POR STATUS DE PAGAMENTO (PAGO ANTES)
        }       
    </script>

</head>

<body>
    <!--==========================
    Header Section
    ============================-->
    <header id="header">
        <div class="container">

            <div id="logo" class="pull-left">
            <!--Trocar ou apagar - Caso haja um logo-->
            <!-- <a href="#hero"><img src="img/logo.png" alt="" title="" /></img></a> -->
            <!-- Uncomment below if you prefer to use a text image -->
            <h1><a href="#hero">JTI</a></h1>
            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu">
                <li class="menu-active"><li><a href="../view/perfilAcademico.php">Meu Perfil</a></li>
                <li><a href="../view/palestrasAcademico.php">Palestras</a></li>
                <li><a href="../view/minicursosAcademico.php">Minicursos</a></li>
                <li><a href="../view/horariosAcademico.php">Meus horários</a></li>
                </ul>
            </nav>
            <!-- #nav-menu-container -->
        </div>
        
    </header>
    <!-- #header -->

    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th scope="col" class="cabecalho">Nome</th>
                <th scope="col" class="cabecalho">Vagas</th>
                <th scope="col" class="cabecalho">Período</th>
                <th scope="col" class="cabecalho">Dias</th>
                <th scope="col" class="cabecalho">Status de pagamento</th>
                <th scope="col" class="cabecalho">Ação</th>
            </tr>
        </thead>
        <tbody class="cabecalho" id="minicursos">


            
        </tbody>
        
    </table>
    

    
    <?php 
    /*$dados; // essa variável tem um array com cada linha da tabela

    // vou usar o primeiro resultado para conseguir a lista de colunas.
    // Você pode querer alguma coisa mais robusta, tipo passar uma
    // lista de campos e usar eles na view;
    $colunas = array_keys($dados[0]);
    ?>
    <table>
        <thead>
            <tr>
            <?php foreach ($colunas as $coluna): ?>
                <th><?= $coluna ?></th>
            <?php endforeach; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($dados as $linha): // para cada linha ?>
            <tr>
                <?php foreach ($linha as $key => $value): // para cada campo de cada linha ?>
                <td><?= $value ?></td>
                <?php endforeach ?>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    */?>


<!-- #footer -->
<a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

<!-- Required JavaScript Libraries -->
<script src="../lib/jquery/jquery.min.js"></script>
<script src="../lib/bootstrap/js/bootstrap.min.js"></script>
<script src="../lib/superfish/hoverIntent.js"></script>
<script src="../lib/superfish/superfish.min.js"></script>
<script src="../lib/morphext/morphext.min.js"></script>
<script src="../lib/wow/wow.min.js"></script>
<script src="../lib/stickyjs/sticky.js"></script>
<script src="../lib/easing/easing.js"></script>

<!-- Template Specisifc Custom Javascript File -->
<script src="../js/custom.js"></script>

<script src="../contactform/contactform.js"></script>

</body>


<!-- criar javascript que pegue o valor da variável na coluna "Nome do minicurso" (w3school)
e use para abrir um modal (index.html) com os dados específicos do minicurso escolhido (BD*problem) 
e exiba os botões "matricular" e "desmatricular" (easy)
Obs: o preenchimento da tabela com os dados do BD deve ser efetuado de modo dinâmico (javascript)-->