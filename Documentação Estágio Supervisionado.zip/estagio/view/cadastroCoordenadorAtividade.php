<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">


  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="../lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="../lib/animate-css/animate.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="../css/style.css" rel="stylesheet">

  <!-- =======================================================
    Theme Name: Imperial
    Theme URL: https://bootstrapmade.com/imperial-free-onepage-bootstrap-theme/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->

  <!-- Script necessário para leitura de Estado e Cidade-->
  <script type="text/javascript" src="http://cidades-estados-js.googlecode.com/files/cidades-estados-v0.2.js"></script> 
  <script type="text/javascript">
      window.onload = function() {
          new dgCidadesEstados( 
              document.getElementById('estado'), 
              document.getElementById('cidade'), 
              true
          );
      }
  </script>

</head>

<body>
    <!--==========================
    Header Section
    ============================-->
    <header id="header">
        <div class="container">

        <div id="logo" class="pull-left">
        <!--Trocar ou apagar - Caso haja um logo-->
        <!-- <a href="#hero"><img src="img/logo.png" alt="" title="" /></img></a> -->
        <!-- Uncomment below if you prefer to use a text image -->
        <h1><a href="#hero">JTI</a></h1>
        </div>

        <nav id="nav-menu-container">
                <ul class="nav-menu">
                    <li class="menu-active"><li><a href="../view/perfilCoordenador.php">Meu perfil</a></li>
                    <li><a href="../view/gerenciarMinistrantes.php">Ministrantes</a></li>
                    <li><a href="../view/gerenciarAtividades.php">Atividades</a></li>
                    <li><a href="../view/gerenciarBoletos.php">Boletos</a></li>
                    <li><a href="../view/visualizarPresencas.php">Lista de presença</a></li>
                </ul>
            </nav>
        <!-- #nav-menu-container -->
        </div>
    </header>
    <!-- #header -->

    <div class="container cont">
     <div class="col-md-6 col-sm-8 col-xs-12 col-md-offset-3 col-sm-offset-2 main">
      <form action="../controller/atividadeController.php" method="POST" class="form-horizontal">
        <div align="center">
          <legend><b style="color:#000000">Cadastro de Atividade</b></legend>
        </div>
    
        
        <div class="form-group">
          <label class="col-md-3 control-label">Tipo:</label>
          <div class="col-md-9">
            <select name="tipo" class="form-control">
                <option></option>
                <option value="palestra" >Palestra</option>
                <option value="minicurso">Minicurso</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-3 control-label" for="nome">Nome da atividade:</label>
          <div class="col-md-9">
            <input type="text" class="form-control" name="nome" id="nome">
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-3 control-label" for="descricao">Descrição:</label>
          <div class="col-md-9">
          <textarea rows="4" cols="50" class="form-control" name="descricao" id="descricao"></textarea>
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-3 control-label">Professor:</label>
          <div class="col-md-9">
            <select name="tipo" class="form-control">
                <option></option>
                <option value="palestra" >Falta cód</option>
                <option value="minicurso">PHP</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-3 control-label" for="data">Data:</label>
          <div class="col-md-9">
          <input type="date" class="form-control" name="data" id="data">
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-3 control-label">Período:</label>
          <div class="col-md-9">
            <select name ="periodo" class="form-control">
                <option></option>
                <option value="matutino">Matutino</option>
                <option value="vespertino">Vespertino</option>
                <option value="noturno">Noturno</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-3 control-label" for="hora_inicio">Hora de início (24h):</label>
          <div class="col-md-9">
            <input type="time" class="form-control" name="hora_inicio" id="hora_inicio">
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-3 control-label" for="duracao">Duração (24h):</label>
          <div class="col-md-9">
            <input type="time" class="form-control" name="duracao" id="duracao">
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-3 control-label" for="vagas">Vagas:</label>
          <div class="col-md-9">
            <input type="number" class="form-control" name="vagas" id="vagas">
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-3 control-label" for="custo">Custo:</label>
          <div class="col-md-9">
            <input type="number" step="0.01" min="0" class="form-control" name="custo" id="custo">
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-3 control-label" for="carga_horaria">Carga horária:</label>
          <div class="col-md-9">
            <input type="number" placeholder="minutos" class="form-control" name="carga_horaria" id="carga_horaria">
          </div>
        </div>
        <div class="form-group">
          <div class="col-md-5 col-md-offset-7"> 
            <button class="btn btn-primary pull-right save">
              <span> Cadastrar</span>
            </button>
          </div>  
        </div>
      </form>
    </div>
    </div>
            

    <!-- #footer -->
    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

    <!-- Required JavaScript Libraries -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="lib/superfish/hoverIntent.js"></script>
    <script src="lib/superfish/superfish.min.js"></script>
    <script src="lib/morphext/morphext.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/stickyjs/sticky.js"></script>
    <script src="lib/easing/easing.js"></script>

    <!-- Template Specisifc Custom Javascript File -->
    <script src="js/custom.js"></script>

    <script src="contactform/contactform.js"></script>


</body>