<?php
//Conecta ao BD
$connect = mysqli_connect('localhost','root','','mydb');

class Ministrante{
    public $email;
    public $senha;
    public $cpf_ministrante;
    public $nome;
    public $profissao;
    public $link_organizacao;
    public $resumo_biografia;
    public $rua;
    public $numero;
    public $cep;
    public $complemento;
    public $estado;
    public $cidade;
    public $fixo;
    public $celular;
    public $comercial;

    public function cadastrarMinistrante(){

    }

    public function alterarMinistrante(){

    }

    public function removerMinistrante(){

    }

}    

?>