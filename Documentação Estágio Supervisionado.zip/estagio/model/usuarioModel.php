<?php
//Conecta ao BD
$connect = mysqli_connect('localhost','root','','mydb');

class Usuario{

    public $id_usuario; //
    public $id_endereco; //
    public $email;
    public $senha;
    public $cpf_academico;
    public $nome;
    public $sexo;
    public $curso;
    public $universidade;
    public $ano_entrada;
    public $data_nascimento;
    public $rua;
    public $numero;
    public $cep; 
    public $complemento;
    public $cidade;
    public $estado;
    public $fixo;
    public $celular;
    public $tipo_usuario;

    public function cadastrarUsuario(){
        
    }

    public function alterarUsuario(){

    }

    public function removerUsuario(){

    }

}


?>