<?php 
//Conecta ao BD
$connect = mysqli_connect('localhost','root','','mydb');

class Atividade{

    public $tipo; 
    public $nome;
    public $descricao; 
    public $data;
    public $periodo;
    public $hora_inicio;
    public $duracao;
    public $vagas;
    public $custo;
    public $carga_horaria;

    public function cadastrarAtividade(){

    }

    public function alterarAtividade(){

    }

    public function removerAtividade(){

    }

}

?>