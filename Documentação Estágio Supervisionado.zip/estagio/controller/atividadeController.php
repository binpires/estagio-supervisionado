<?php

//Para teste
$cpf_ministrante = '04099707199';
$aprovacao = true;
$status_pagamento = 'pago';

$tipo = $_POST['tipo'];
$nome = $_POST['nome'];
$descricao = $_POST['descricao'];
$data_atividade = $_POST['data'];
$periodo = $_POST['periodo'];
$hora_inicio = $_POST['hora_inicio'];
$duracao = $_POST['duracao'];
$vagas = $_POST['vagas'];                       //Não obrigatório
$custo = $_POST['custo'];                       //Não obrigatório
$carga_horaria = $_POST['carga_horaria'];       //Não obrigatório

/* Falta "idatividade; cpf_ministrante; cpf_academico; status_pagamento - Tratamento será realizado no Model*/

//Conecta ao BD
$connect = mysqli_connect('localhost','root','','mydb');

if(($tipo == "" || $tipo == NULL) || ($nome == "" || $nome == NULL) || ($descricao == "" || $descricao == NULL) || 
($data_atividade == "" || $data_atividade == NULL) || ($periodo == "" || $periodo == NULL) || ($hora_inicio == "" || $hora_inicio == NULL) || 
($duracao == "" || $duracao == NULL))
{
    echo"Preencha os campos obrigatórios";
}else{
    $query = "INSERT INTO atividades (cpf_ministrante,tipo,nome,descricao,aprovacao,data_atividade,periodo,hora_inicio,duracao,vagas,custo,status_pagamento) VALUES 
    ('$cpf_ministrante','$tipo','$nome','$descricao',$aprovacao,'$data_atividade','$periodo','$hora_inicio','$duracao',$vagas,$custo,'$status_pagamento',$carga_horaria)";
    $result = mysqli_query($connect,$query);

    if($result){
      echo"Usuário cadastrado com sucesso";
      mysqli_close($connect);
    }else{
      $erro = mysqli_error($result);
      echo "$erro";
    }

}

?>