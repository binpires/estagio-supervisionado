<?php

//Carregar Model

$email = $_POST['email'];
$senha = $_POST['senha'];
$confirmacao_senha = $_POST['confirmacao_senha'];
$cpf_ministrante = $_POST['cpf_ministrante'];
$nome = $_POST['nome'];
$profissao = $_POST['profissao'];
$link_organizacao = $_POST['link_organizacao'];         //Não obrigatório
$resumo_biografia = $_POST['resumo_biografia'];         //Não obrigatório
$rua = $_POST['rua'];
$numero = $_POST['numero'];
$cep = $_POST['cep'];
$complemento = $_POST['complemento'];                   //Não obrigatório
$estado = $_POST['estado'];
$cidade = $_POST['cidade'];
$fixo = $_POST['fixo'];                                 //Não obrigatório
$celular = $_POST['celular'];                           //Não obrigatório
$comercial = $_POST['comercial'];                       //Não obrigatório

$tipo_usuario = "ministrante";

//Conecta ao BD
$connect = mysqli_connect('localhost','root','','mydb');
//Código para realizar a busca por email já cadastrado
$query_select = "SELECT email FROM usuarios WHERE email = '$email'";
//Realiza a busca por email já cadastrado
$select = mysqli_query($connect, $query_select);
$array = mysqli_fetch_array($select);
$logarray = $array['email'];

if(($email == '' || $email == NULL) || ($senha == '' || $senha == NULL) || 
($confirmacao_senha == '' || $confirmacao_senha == NULL) || ($cpf_ministrante == '' || $cpf_ministrante == NULL) ||
($nome == '' || $nome == NULL) || ($profissao == '' || $profissao == NULL) || 
($rua == '' || $rua == NULL) || ($numero == '' || $numero == NULL) || ($cep == '' || $cep == NULL) || 
($estado == '' || $estado == NULL) || ($cidade == '' || $cidade == NULL))
{
echo"Preencha os campos obrigatórios";
    
  }else{
      if($logarray == $email){
        echo "E-mail já cadastrado";
        die();
      }else if($senha == $confirmacao_senha){
        $senha = MD5($_POST['senha']);
        
        $query = "INSERT INTO ministrantes (cpf_ministrante,nome,profissao,link_organizacao,resumo_biografia) VALUES ('$cpf_ministrante','$nome','$profissao','$link_organizacao','$resumo_biografia');";
        $result = mysqli_query($connect,$query);
        //mysqli_free_result($result);

        $query = "INSERT INTO usuarios (email,senha,tipo_usuario,cpf_ministrante) VALUES ('$email','$senha','$tipo_usuario','$cpf_ministrante')";
        $result = mysqli_query($connect,$query);

        $query = "INSERT INTO enderecos (id_usuario,rua,numero,cep,complemento,cidade,estado) VALUES (LAST_INSERT_ID(),'$rua',$numero,$cep,'$complemento','$cidade','$estado')";
        $result = mysqli_query($connect,$query);

        $query = "INSERT INTO contato (id_usuario,fixo,celular,comercial) VALUES (LAST_INSERT_ID(),$fixo,$celular,$comercial)";
        $result = mysqli_query($connect,$query);

        if($result){
          echo"Usuário cadastrado com sucesso";
          mysqli_close($connect);
        }else{
          $erro = mysqli_error($result);
          echo "$erro";
        }

      }else{
        /* Exibir mensagem de incompatibilidade entre senha e confirmação*/
        echo "Senhas não conferem";
      }

      

  }
?>