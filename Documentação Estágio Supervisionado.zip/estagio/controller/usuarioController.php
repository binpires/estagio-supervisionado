<?php 

//Carregar o Model 


//Dados necessário para cadastro & realização do login
$email = $_POST['email'];   
$senha = $_POST['senha'];

//Dados necessário para cadastro
$confirmacao_senha = $_POST['confirmacao_senha'];
$cpf_academico = $_POST['cpf_academico'];
$nome = $_POST['nome'];
$sexo = $_POST['sexo'];
$curso = $_POST['curso'];
$universidade = $_POST['universidade'];
$ano_entrada = $_POST['ano_entrada'];
$data_nascimento = $_POST['data_nascimento'];
$rua = $_POST['rua'];
$numero = $_POST['numero'];
$cep = $_POST['cep'];
$complemento = $_POST['complemento'];                      //Não obrigatório
$cidade = $_POST['cidade'];
$estado = $_POST['estado'];
$fixo = $_POST['fixo'];                                    //Não obrigatório 
$celular = $_POST['celular'];                              //Não obrigatório 

$tipo_usuario = "academico";                               //Predefinido

//Conecta ao BD
$connect = mysqli_connect('localhost','root','','mydb');
//Código para realizar a busca por email já cadastrado
$query_select = "SELECT email FROM usuarios WHERE email = '$email'";
//Realiza a busca por email já cadastrado
$select = mysqli_query($connect, $query_select);
$array = mysqli_fetch_array($select);
$logarray = $array['email'];
 
  if(($email == "" || $email == null) || ($senha == "" || $senha == null) || ($confirmacao_senha == "" || $confirmacao_senha == null)
  || ($cpf_academico == "" || $cpf_academico == null) || ($nome == "" || $nome == null) || ($sexo == "" || $sexo == null) 
  || ($curso == "" || $curso == null) || ($universidade == "" || $universidade == null) 
  || ($ano_entrada == "" || $ano_entrada == null) || ($data_nascimento == "" || $data_nascimento == null) 
  || ($rua == "" || $rua == null) || ($numero == "" || $numero == null) || ($cep == "" || $cep == null)
  || ($cidade == "" || $cidade == null) || ($estado == "" || $estado == null))
  {
    echo"Preencha os campos obrigatórios";
    
  }else{
      if($logarray == $email){
        echo "E-mail já cadastrado";
        die();
      }else if($senha == $confirmacao_senha){
        $senha = MD5($_POST['senha']);
        //Separada por ; : NÃO FUNCIONA
        //$query = "INSERT INTO academicos (cpf_academico,nome,sexo,curso,universidade,ano_entrada,data_nascimento) VALUES ('$cpf_academico','$nome','$sexo','$curso','$universidade',$ano_entrada,'$data_nascimento');INSERT INTO usuarios (email,senha,tipo_usuario) VALUES ('$email','$senha','$tipo_usuario')"
        //$query = "START TRANSACTION;INSERT INTO academicos (cpf_academico,nome,sexo,curso,universidade,ano_entrada,data_nascimento) VALUES ('$cpf_academico','$nome','$sexo','$curso','$universidade',$ano_entrada,'$data_nascimento');INSERT INTO usuarios (email,senha,tipo_usuario,cpf_academico) VALUES ('$email','$senha','$tipo_usuario','$cpf_academico');COMMIT;"
        //Funciona separadamente - Necessário inserir academico antes do usuário
        //$query = "INSERT INTO academicos (cpf_academico,nome,sexo,curso,universidade,ano_entrada,data_nascimento) VALUES ('$cpf_academico','$nome','$sexo','$curso','$universidade',$ano_entrada,'$data_nascimento');";
        //Funciona separadamente 
        //$query = "INSERT INTO usuarios (email,senha,tipo_usuario) VALUES ('$email','$senha','$tipo_usuario')";               
        
        $query = "INSERT INTO academicos (cpf_academico,nome,sexo,curso,universidade,ano_entrada,data_nascimento) VALUES ('$cpf_academico','$nome','$sexo','$curso','$universidade',$ano_entrada,'$data_nascimento');";
        $result = mysqli_query($connect,$query);
        //mysqli_free_result($result);

        $query = "INSERT INTO usuarios (email,senha,tipo_usuario,cpf_academico) VALUES ('$email','$senha','$tipo_usuario','$cpf_academico')";
        $result = mysqli_query($connect,$query);

        $query = "INSERT INTO enderecos (id_usuario,rua,numero,cep,complemento,cidade,estado) VALUES (LAST_INSERT_ID(),'$rua',$numero,$cep,'$complemento','$cidade','$estado')";
        $result = mysqli_query($connect,$query);

        $query = "INSERT INTO contato (id_usuario,fixo,celular) VALUES (LAST_INSERT_ID(),$fixo,$celular)";
        $result = mysqli_query($connect,$query);

        if($result){
          echo"Usuário cadastrado com sucesso";
          mysqli_close($connect);
        }else{
          $erro = mysqli_error($result);
          echo "$erro";
        }

      }else{
        /* Exibir mensagem de incompatibilidade entre senha e confirmação*/
        echo "Senhas não conferem";
      }

      

  }
?>